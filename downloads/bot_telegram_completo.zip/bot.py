from telegram.ext import Updater, CommandHandler, CallbackQueryHandler
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
import os

# Função de boas-vindas
def start(update, context):
    keyboard = [
        [InlineKeyboardButton("Ver Produtos", callback_data='produtos')],
        [InlineKeyboardButton("Fazer Pedido", callback_data='pedido')],
        [InlineKeyboardButton("Entrar em Contato", callback_data='contato')],
        [InlineKeyboardButton("Pagar com Pix", callback_data='pix')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text("🚗 *Seja bem-vindo à minha lojinha!* 🚗\n\nClique em uma das opções abaixo:", reply_markup=reply_markup, parse_mode='Markdown')

# Função para mostrar os produtos
def produtos(update, context):
    tabela = """
🚗 *Sejam bem-vindos à minha lojinha!* 🚗  
💥 Instagram: @arthur.vendas01

*Golds com World Sale*  
10k: R$1,50  
20k: R$2,50  
30k: R$3,50  

*Golds sem World Sale*  
90k: R$3,65  
100k: R$4,00  
150k: R$4,25  
200k: R$4,50  
250k: R$4,75  
300k: R$5,00  
350k: R$5,25  
400k: R$5,50  
450k: R$5,75  
500k: R$6,00  

*Money*  
10M: R$1,00  
20M: R$2,00  
30M: R$3,00  
40M: R$4,00  
50M: R$5,00  

*Desbloqueios na Conta*  
W16: R$4,00  
Fumaça: R$3,50  
Todos os carros pagos: R$3,50  
Todos os carros de gold: R$2,00  
Desbloquear casa paga: R$4,00  
Buzinas pagas: R$5,00  
Sirene em todos os carros: R$4,00  
King: R$3,50  
Nome RGB: R$2,00  

📲 *Pagamento via Pix*  
Chave Pix: 79999598533
"""
    update.callback_query.message.reply_text(tabela, parse_mode='Markdown')

# Função para fazer o pedido
def pedido(update, context):
    update.callback_query.message.reply_text("📋 *Envie seu pedido no formato:* /pedido Produto + Quantidade\n\nExemplo: /pedido 200k gold + W16")

# Função para contato
def contato(update, context):
    update.callback_query.message.reply_text("📞 Entre em contato comigo via WhatsApp: [Clique aqui](https://wa.me/79999598533)", parse_mode='Markdown')

# Função para Pix
def pix(update, context):
    update.callback_query.message.reply_text("🔑 Chave Pix: 79999598533")

# Função para lidar com os botões
def button(update, context):
    query = update.callback_query
    query.answer()
    if query.data == 'produtos':
        produtos(update, context)
    elif query.data == 'pedido':
        pedido(update, context)
    elif query.data == 'contato':
        contato(update, context)
    elif query.data == 'pix':
        pix(update, context)

# Substitua "SEU_TOKEN_AQUI" pelo token do seu bot
updater = Updater("7574937721:AAH8uxU-T95ChxUy2_fLiOmkHtDjXlKCzHw", use_context=True)
dp = updater.dispatcher

dp.add_handler(CommandHandler("start", start))
dp.add_handler(CallbackQueryHandler(button))

updater.start_polling()
updater.idle()
