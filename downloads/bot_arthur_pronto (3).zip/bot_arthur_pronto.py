
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = (
        "Bem-vindo à Tabela do Arthurzin!

"
        "Golds com world sale:
"
        "10k: 1,50
20k: 2,50
30k: 3,50

"
        "Golds sem world sale:
"
        "90k: 3,65
100k: 4,00
150k: 4,25
200k: 4,50
"
        "250k: 4,75
300k: 5,00
350k: 5,25
400k: 5,50
"
        "450k: 5,75
500k: 6,00

"
        "Money:
"
        "10m: 1 real
20m: 2 reais
30m: 3 reais
"
        "40m: 4 reais
50m: 5 reais

"
        "Desbloqueios:
"
        "W16: 4 reais
Fumaça: 3,50
Todos carros pagos: 3,50
"
        "Carros de gold: 2 reais
Casa paga: 4 reais
"
        "Buzinas pagas: 5 reais
Sirene: 4 reais
King: 3,50
RGB: 2 reais

"
        "Instagram: @arthur.vendas01"
    )
    await update.message.reply_text(message)

if __name__ == "__main__":
    import os
    import asyncio

    TOKEN = os.environ.get("BOT_TOKEN")
    if not TOKEN:
        print("Erro: defina a variável de ambiente BOT_TOKEN")
        exit(1)

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    print("Bot iniciado...")
    app.run_polling()
